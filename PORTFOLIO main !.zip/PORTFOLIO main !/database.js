// const mongoose = require('mongoose');

// const url = 'mongodb://127.0.0.1/portfolio'

// mongoose.connect(url,{useNewUrlParser:true})

// const con = mongoose.connection

// con.on('open',function(){
//     console.log("connected to database")
// })

// const loginSchema=new mongoose.Schema(
//     {
//         username:
//         {
//             type:String,
//             required:true
//         },
//         password:
//         {
//             type:String,
//             required:true
//         }
//     }
// )

// const registerSchema=new mongoose.Schema(
//     {
//         username:
//         {
//             type:String,
//             required:true
//         },
//         password:
//         {
//             type:String,
//             required:true
//         },
//         portfolio:
//         {
//             type:String,
//             required:true
//         }
//     }
// )

// loginModel=mongoose.model('loginModel',loginSchema)
// registerModel=mongoose.model('registerModel',registerSchema)

// module.exports={loginModel,registerModel}