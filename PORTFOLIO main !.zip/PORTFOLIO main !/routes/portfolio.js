const express = require('express')
const router = new express.Router()
const portfolio1 = require('../models/portfolio')

router.get('/', async(req, res) =>{
    try{
        const s1 = await portfolio1.find()
        res.json(s1)
    }catch(err){
        res.send('error' +err)
    }
})

router.post('/', async(req, res) =>{
    const portfolio2 = new portfolio1({
        username:req.body.username,
        password:req.body.password,
        portfolio:req.body.portfolio
    })
    try{
        const s2 = await portfolio2.save()
        res.json(s2)
    }
    catch(err)
    {
        res.send('error' +err)
    }
})

module.exports = router 