const express = require('express')
const fileUpload = require('express-fileupload');
const mongoose  = require('mongoose')
const index = express()
const bodyParser = require('body-parser');  
index.use(bodyParser.urlencoded({ extended: false }));
const portfolio1 = require('./models/portfolio')
const url = 'mongodb://127.0.0.1/portfolio'
const router = express.Router();


mongoose.connect(url,{useNewUrlParser:true})
     
const con = mongoose.connection


con.on('open',function(){
    console.log("connected to database")
})
index.use(fileUpload())
index.use(express.json())
const stuRouter = require('./routes/portfolio');
const { db } = require('./models/portfolio');
index.use('/portfolio', stuRouter)

index.listen(9000, ()=>{
    console.log("hello world")
    console.log("server started")
})

// serve your css as static
index.use(express.static(__dirname));

index.get("/login", (req, res) => {
    res.sendFile(__dirname + "/login.html");
});
index.post('/login', (req, res) => {
    // Insert Login Code Here
    // res.send(req.body.username)
    let username1 = req.body.username;
    let password1 = req.body.password;
    portfolio1.findOne({username:username1 }, function (err, docs) {
        try{
            if (err){
                res.status(400).send("Try Again");
            }
            else{
                // console.log("Result : ", docs,docs.password);
                if (docs.password == password1){
                    // res.status(200).send("pw match");
                    res.sendFile(__dirname + "/upload.html");
                }
                else{
                    res.status(200).send("pw not match");
                }
            }
        }
        catch(e){
            res.status(400).send('try again');
        }
      
    });
    // res.send(`Username: ${username1} Password: ${password1}`);
  });


index.get("/", (req, res) => {
    res.sendFile(__dirname + "/index.html");
  });

index.post('/', function(req, res){
    if (req.files) {
        // console.log(req.files)
        var file = req.files.filename
        console.log(file)
        var filename = file.name
        // console.log(filename)

        file.mv('./uploads/'+filename,function (err){
            if(err){
                res.send(err)

            } else {
                res.send("file uploaded")
            }
        })
    }
} )

var app=express()

app.use(bodyParser.json());
app.use(express.static('public'));
app.use(bodyParser.urlencoded({
	extended: true
}));

index.get("/", (req, res) => {
    res.sendFile(__dirname + "/index.html");
  });

index.post('/signup', function(req,res){
	var username = req.body.username;
	var password =req.body.password;

	var data = {
		"username": username,
		"password": password
		
	}
    con.collection('portfolio1').insertOne(data,function(err, collection){
		if (err) throw err;
		console.log("Record inserted Successfully");
			
	});
		
	return res.redirect('login.html');
})


index.get('/',function(req,res){
res.set({
	'Access-control-Allow-Origin': '*'
	});
return res.redirect('login.html');
})